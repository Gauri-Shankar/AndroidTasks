package com.example.chatapp

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

// TODO: Rename parameter arguments, choose names that match

class chatFragment : Fragment() {
    // TODO: Rename and change types of parameters

    private lateinit var fragmentView:View
    private lateinit var recyclerView: RecyclerView
    lateinit var chatList: MutableList<String>
    lateinit var adapter: chatAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        fragmentView =  inflater.inflate(R.layout.fragment_chat, container, false)

        return fragmentView
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        recyclerView = fragmentView.findViewById(R.id.recyclerView)
        chatList = mutableListOf("Hello world", "World is Listening", "Channel is working fine", "Closing conversation")
        recyclerView.layoutManager = LinearLayoutManager(context)
        adapter = chatAdapter(chatList)
        recyclerView.adapter = adapter
    }
}