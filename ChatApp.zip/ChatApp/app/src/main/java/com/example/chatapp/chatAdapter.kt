package com.example.chatapp

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView


class chatAdapter(chatList:MutableList<String>):  RecyclerView.Adapter<RecyclerView.ViewHolder>(){

    private var chatMessages:MutableList<String> = chatList


    override fun getItemViewType(position: Int): Int {
        return position % 2
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        when(viewType){
            0 -> {
                var view: View? =
                    LayoutInflater.from(parent.context).inflate(R.layout.layout, parent, false)
                return ViewHolder0(view!!)
            };
            1 -> {
                var view:View? = LayoutInflater.from(parent.context).inflate(R.layout.layout2, parent , false)
                return ViewHolder1(view!!);
            }
            else -> {
                var view:View? = LayoutInflater.from(parent.context).inflate(R.layout.layout, parent , false)
                return ViewHolder0(view!!);
            }
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when(holder.itemViewType){
            0 -> {
                val viewHolder0 = holder as ViewHolder0
                viewHolder0.textView.setText(chatMessages[position])
            }
            else -> {
                val viewHolder1 = holder as ViewHolder1
                viewHolder1.textView.setText(chatMessages[position])
            }
        }
    }


    override fun getItemCount(): Int {
        return chatMessages.size
    }

    class ViewHolder0(view: View): RecyclerView.ViewHolder(view){
        var textView:TextView = view.findViewById(R.id.textView)
    }

    class ViewHolder1(view: View):RecyclerView.ViewHolder(view){
        var textView: TextView = view.findViewById(R.id.textView2)

    }
}