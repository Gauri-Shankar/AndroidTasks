package com.example.retrofitapi

import android.util.EventLogTags

class RetrofitModel {

    lateinit var tags:MutableList<String>
    lateinit var id:String
    lateinit var content:String
    lateinit var author:String
    lateinit var authorSlug:String
    var length:Int = 0
    lateinit var dateAdded:String
    lateinit var dateModified:String




}