package com.example.retrofitapi

data class Data (
    var tags:List<String>,
    var _id:String,
    var author:String,
    var content:String,
    var authorSlug:String,
    var length:String,
    var dateAdded:String,
    var dateModified:String

)