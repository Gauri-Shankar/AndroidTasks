package com.example.retrofitapi

data class JsonModel (

    var count:String,
    var totalCount:String,
    var page:String,
    var totalPages:String,
    var lastItemIndex:String,
    var results:List<Data>

)