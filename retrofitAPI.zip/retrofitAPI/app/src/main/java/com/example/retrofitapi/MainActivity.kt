package com.example.retrofitapi

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.sql.Types.NULL


class MainActivity : AppCompatActivity() {

    val JSONURL:String = "https://quotable.io/";
    var dataList:MutableList<Data> = mutableListOf()

    var rcv:RecyclerView?=null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        rcv = findViewById(R.id.recyclewView)
        getResponse()
    }


    private fun getResponse() {
        val retrofit = Retrofit.Builder()
            .baseUrl(JSONURL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(retrofitInterface::class.java)



        val retrofitData = retrofit.getData();

        retrofitData?.enqueue(object : Callback<JsonModel?> {
            override fun onResponse(call: Call<JsonModel?>, response: Response<JsonModel?>) {
                var data:JsonModel? = response.body();
                for(d in data!!.results){
                    dataList.add(d)
                }
                Log.d("Response is", data?.results?.size.toString())
                var adapter = JsonAdapter(data?.results)
                rcv?.layoutManager = LinearLayoutManager(applicationContext)
                rcv?.adapter = adapter
            }

            override fun onFailure(call: Call<JsonModel?>, t: Throwable) {

            }
        })
    }
}
//rxjava, coroutine