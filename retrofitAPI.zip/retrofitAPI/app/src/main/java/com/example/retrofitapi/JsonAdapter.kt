package com.example.retrofitapi

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class JsonAdapter(jsonDataList: List<Data>): RecyclerView.Adapter<JsonAdapter.ViewHolder>() {

    var dataList:List<Data> = jsonDataList
    lateinit var view:View

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): JsonAdapter.ViewHolder {
        view = LayoutInflater.from(parent.context).inflate(R.layout.recyclerview_item,parent, false)
        return ViewHolder(view!!)
    }

    override fun getItemCount(): Int {
        return dataList.size
    }

    override fun onBindViewHolder(holder: JsonAdapter.ViewHolder, position: Int) {
        var s = "Tags = ";
        for(tag in dataList[position].tags){
            s+=tag;
            s+=" "
        }
        s += '\n';
        s+= "ID = "
        s+= dataList[position]._id;
        s+='\n'
        s+= "Author = "
        s += dataList[position].author
        s += '\n'
        s += "Content =  "
        s += dataList[position].content
        holder.textView.setText(s)
    }


    class ViewHolder(view: View): RecyclerView.ViewHolder(view){
        var textView: TextView = view.findViewById(R.id.textView)
    }
}/*
        activity, service, broadcast receiver, content provider
        fragment, recyclerview, coordinator layout, frame layout, motion layout,
        mvvm, hilt, dagger2(dependency injection), coroutines, kotlin, keywords, */