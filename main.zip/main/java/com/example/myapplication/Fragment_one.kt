package com.example.myapplication

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class Fragment_one(fragmentOneCallBackListener: FragmentOneCallBackListener): Fragment(), Image_Adapter.ViewHolder.RecyclerViewListener{

    var rcv:RecyclerView?=null
    var imageList:MutableList<Int>?=null
    var adapter:Image_Adapter?=null
    var fragmentOneCallBackListener1:FragmentOneCallBackListener = fragmentOneCallBackListener

    override fun onCreateView(inflater: LayoutInflater,
                              container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {

        var view:View = inflater.inflate(R.layout.fragment_one, container, false)
        rcv = view.findViewById(R.id.recyler_one)

        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        imageList = mutableListOf(R.drawable.image4, R.drawable.image3, R.drawable.image2)
        rcv?.layoutManager = LinearLayoutManager(context)
        adapter = Image_Adapter(imageList!!, this!!)
        rcv?.adapter = adapter

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun RecyclerViewListClicked(pos:Int) {
        if(pos >= imageList!!.size){
            Log.d("DEBUG MESSAGE", "ARRAYLIST SIZE EXCEEDED")
            return
        }else {
            var imageID: Int = imageList!![pos]
            adapter!!.updateDatabase(imageID, false, pos)
            fragmentOneCallBackListener1!!.sendMessageToActivity_1(imageID, true)
        }
    }

    fun downloadImage(imageId:Int, add:Boolean){
        adapter!!.updateDatabase(imageId, true, 0)
    }
    interface FragmentOneCallBackListener{
        fun sendMessageToActivity_1(imageID:Int, delete:Boolean)
    }

}