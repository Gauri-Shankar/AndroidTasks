package com.example.myapplication


import android.content.Context
import android.graphics.BitmapFactory
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView


class Image_Adapter(var imageList: MutableList<Int>, var recyclerViewListener: ViewHolder.RecyclerViewListener) : RecyclerView.Adapter<Image_Adapter.ViewHolder>() {

    // create new views
    //var imageView:ImageView?=null
    var context:Context?=null

    var recyclerViewListener1:ViewHolder.RecyclerViewListener? = null;

    init{
        recyclerViewListener1 = recyclerViewListener;
    }


    fun updateDatabase(imageID: Int, add: Boolean, pos:Int){
        if(add){
            imageList += imageID
            notifyItemInserted(imageList.size-1)
        }
        else{
            imageList -= imageID
            notifyItemRemoved(pos)
        }
        notifyDataSetChanged()
    }





    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        // inflates the card_view_design view
        // that is used to hold list item
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.fragment_one_item, parent, false)

        context = view.context
        Log.d("List size is"," :"+imageList.size)

        return ViewHolder(view, recyclerViewListener1!!)
    }

    // binds the list items to a view
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        val ItemsViewModel:Int = imageList[position]

        // sets the image to the imageview from our itemHolder class

        //var bmp:Bitmap = BitmapFactory.decodeResource(Resources.getSystem(), R.drawable.image2)

        //Log.d("Bitmap Size", ""+bmp.height+" "+bmp.width)
        val bitmap = BitmapFactory.decodeResource(context?.resources, ItemsViewModel)

        /*bitmap.height = holder.imageView.height
        bitmap.width = holder.imageView.width
        Log.d("shape of itemsview is",""+bitmap.width+" "+bitmap.height)*/

        holder.imageView.setImageResource(ItemsViewModel)
        var context1:Context = holder.imageView.context

    }

    // return the number of the items in the list
    override fun getItemCount(): Int {
        return imageList.size

    }

    // Holds the views for adding it to image and text
    class ViewHolder(ItemView: View, recyclerViewListener: RecyclerViewListener) : RecyclerView.ViewHolder(ItemView), View.OnClickListener {
        val imageView: ImageView = itemView.findViewById(R.id.imageView)
        var ItemView1:View?=null
        var recyclerViewListener1:RecyclerViewListener?=null;

        init{
            ItemView1 = ItemView;
            recyclerViewListener1 = recyclerViewListener;
            ItemView.setOnClickListener(this)
        }

        override fun onClick(v: View?) {
            var pos:Int = adapterPosition
            recyclerViewListener1?.RecyclerViewListClicked(pos);
        }

        interface RecyclerViewListener{
            fun RecyclerViewListClicked(id:Int);
        }
    }
}
