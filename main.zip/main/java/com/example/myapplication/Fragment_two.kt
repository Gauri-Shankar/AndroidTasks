package com.example.myapplication

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class Fragment_two(fragmentTwoCallBackListener: FragmentTwoCallBackListener): Fragment(), Image_Adapter.ViewHolder.RecyclerViewListener {

    var rcv:RecyclerView?=null
    var imageList:MutableList<Int>?=null
    var adapter:Image_Adapter?=null
    var fragmentTwoCallBackListener1:FragmentTwoCallBackListener?=fragmentTwoCallBackListener
    override fun onCreateView(inflater: LayoutInflater,
                              container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        var view:View =  inflater.inflate(R.layout.fragment_two, container, false)
        rcv = view.findViewById(R.id.recyler_two)

        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        imageList = mutableListOf(R.drawable.image2, R.drawable.image3, R.drawable.image4)
        rcv?.layoutManager = LinearLayoutManager(context)
        adapter = Image_Adapter(imageList!!, this!!)
        rcv?.adapter = adapter

    }

    override fun RecyclerViewListClicked(pos:Int) {
        if(pos >= imageList!!.size){
            Log.d("DEBUG MESSAGE", "ArrayList Size exceeded")
            return
        }
        else {
            var imageID: Int = imageList!![pos]
            adapter?.updateDatabase(imageID, false, pos)
            fragmentTwoCallBackListener1?.sendMessageToActivity_2(imageID, true)
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    fun downloadImage(imageId:Int, add:Boolean){
        adapter!!.updateDatabase(imageId, true, 0)
    }

    interface FragmentTwoCallBackListener{
        fun sendMessageToActivity_2(imageId: Int, delete:Boolean)
    }

}