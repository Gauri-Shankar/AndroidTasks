package com.example.myapplication


import android.os.Bundle
import android.util.Log
import android.widget.FrameLayout
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.fragment.app.FragmentTransaction
import androidx.fragment.app.commit


class MainActivity : FragmentActivity(), Fragment_one.FragmentOneCallBackListener, Fragment_two.FragmentTwoCallBackListener{

    var frag1:FrameLayout?=null
    var frag2:FrameLayout?=null
    var fragment1:Fragment_one?=null
    var fragment2:Fragment_two?=null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main)

        frag1 = findViewById(R.id.fragment_one) as FrameLayout    // container 1
        frag2 = findViewById(R.id.fragment_two) as FrameLayout    // container 2

        fragment1 = Fragment_one(this);
        fragment2= Fragment_two(this);

        val ft: FragmentTransaction = supportFragmentManager.beginTransaction()
        ft.add(R.id.fragment_one,fragment1!!)
        ft.add(R.id.fragment_two, fragment2!!)
        //Toast.makeText(baseContext, "app started", Toast.LENGTH_LONG)
        Log.d("debug message","working")
        ft.commit()

    }

    override fun sendMessageToActivity_1(imageId:Int, add:Boolean) {
        fragment2!!.downloadImage(imageId, add);
    }

    override fun sendMessageToActivity_2(imageId:Int, add:Boolean) {
        fragment1!!.downloadImage(imageId, add)
    }

}